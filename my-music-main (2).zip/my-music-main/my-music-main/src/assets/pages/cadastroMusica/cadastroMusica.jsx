import { useEffect, useState } from "react";
import "./cadastroMusica.css";
import api from "../../../services/services"

export const CadastroMusica = () => {

    const [id, setId] = useState(0);
  const [musicas, setMusicas] = useState([]);
  const [nome, setNome] = useState("");
  const [artista, setArtista] = useState("");

    async function carregarMusicas() {
    const retorno = await api.get("/musicas");
    setMusicas(retorno.data);
  }

      useEffect(() => {
    carregarMusicas();
  }, []);


  async function cadastrarMusica() {
    if (nome == null || artista == null) {
      alert("Preencha todos os campos!");
      return;
    }

    const objMusica = {
        nome: nome,
        artista: artista
    }

    await api.post("/musicas", {
      nome,
      artista,
    });

    setNome("");
    setArtista("");

    carregarMusicas();
  }
}

