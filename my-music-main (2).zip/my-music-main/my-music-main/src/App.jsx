import "./App.css";
import { useEffect, useState } from "react";
import api from "../src/services/services";

function App() {

  const [musicas, setMusicas] = useState([]);
  const [nome, setNome] = useState("");
  const [artista, setArtista] = useState("");


  async function carregarMusicas() {
    const retorno = await api.get("/musicas");
    setMusicas(retorno.data);
  }

  useEffect(() => {
    carregarMusicas();
  }, []);


  async function cadastrarMusica() {
    if (nome === "" || artista === "") {
      alert("Preencha todos os campos!");
      return;
    }

    await api.post("/musicas", {
      nome,
      artista,
    });

    setNome("");
    setArtista("");

    carregarMusicas();
  }


  return (
    <div className="container">
      <div className="card">
        <h1>MyMusic</h1>
        <p className="subtitle">Cadastre suas músicas favoritas</p>


        <div className="formulario">
          <input 
            type="text" 
            placeholder="Nome da música" 
            value={nome}
            onChange={(e) => setNome(e.target.value)} 
          />

          <input 
            type="text" 
            placeholder="Artista" 
            value={artista}
            onChange={(e) => setArtista(e.target.value)} 
          />

          <button onClick={cadastrarMusica}>Cadastrar</button>
        </div>

        <div className="lista-musicas">
          <h2>Minhas músicas</h2>


          {musicas.map((musica) => (
            <div key={musica.id} className="musica-card">
              <div>
                <h3>{musica.nome}</h3>
                <p>{musica.artista}</p>
              </div>
              
              <button 
                className="btn-delete" 
                onClick={() => excluirMusica(musica.id)} 
              >
                
              </button>
            </div>
          ))}

 
          {musicas.length === 0 && (
            <p> Nenhuma música. </p>
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
